# -*- coding: utf-8 -*-
# COPYRIGHT (C) 2011-2015 MOBICAGE NV
# ALL RIGHTS RESERVED.
#
# ALTHOUGH YOU MAY BE ABLE TO READ THE CONTENT OF THIS FILE, THIS FILE
# CONTAINS CONFIDENTIAL INFORMATION OF MOBICAGE NV. YOU ARE NOT ALLOWED
# TO MODIFY, REPRODUCE, DISCLOSE, PUBLISH OR DISTRIBUTE ITS CONTENT,
# EMBED IT IN OTHER SOFTWARE, OR CREATE DERIVATIVE WORKS, UNLESS PRIOR
# WRITTEN PERMISSION IS OBTAINED FROM MOBICAGE NV.
#
# THE COPYRIGHT NOTICE ABOVE DOES NOT EVIDENCE ANY ACTUAL OR INTENDED
# PUBLICATION OF SUCH SOURCE CODE.
#
# @@license_version:1.8@@

import inspect
import json
import threading

from google.appengine.ext import webapp
from mcfw.consts import AUTHENTICATED, NOT_AUTHENTICATED
from mcfw.rpc import run, parse_parameters


_exposed = dict()
_precall_hooks = list()
_postcall_hooks = list()

def register_precall_hook(callable_):
    _precall_hooks.append(callable_)

def register_postcall_hook(callable_):
    _postcall_hooks.append(callable_)

def rest(uri, method, authenticated=True, silent=False, silent_result=False):
    if not method in ('get', 'post'):
        ValueError('method')

    def wrap(f):
        if not inspect.isfunction(f):
            raise ValueError("f is not of type function!")

        def wrapped(*args, **kwargs):
            return f(*args, **kwargs)

        wrapped.__name__ = f.__name__
        wrapped.meta = {"rest": True, "uri": uri, "method": method, "authenticated": authenticated, "silent": silent, "silent_result": silent_result}
        if hasattr(f, "meta"):
            wrapped.meta.update(f.meta)
        return wrapped

    return wrap

class ResponseTracker(threading.local):

    def __init__(self):
        self.current_response = None
        self.current_request = None

_current_reponse_tracker = ResponseTracker()
del ResponseTracker

class GenericRESTRequestHandler(webapp.RequestHandler):

    @staticmethod
    def getCurrentResponse():
        return _current_reponse_tracker.current_response

    @staticmethod
    def getCurrentRequest():
        return _current_reponse_tracker.current_request

    @staticmethod
    def clearCurrent():
        _current_reponse_tracker.current_response = None

    @staticmethod
    def setCurrent(request, response):
        _current_reponse_tracker.current_request = request
        _current_reponse_tracker.current_response = response

    def ctype(self, type_, value):
        if not isinstance(type_, (list, tuple)):
            return type_(value)
        elif isinstance(type_, list):
            return [self.ctype(type_[0], item) for item in value.split(',')]
        elif type_ == (str, unicode):
            return unicode(value)
        elif type_ == (int, long):
            return long(value)
        raise NotImplementedError()

    def get(self):
        GenericRESTRequestHandler.setCurrent(self.request, self.response)
        key = self.request.path, "get"
        if not key in _exposed:
            self.response.set_status(404, "Call not found!")
            return
        f = _exposed[key]
        kwargs = dict(((name, self.ctype(type_, self.request.GET[name])) for name, type_ in f.meta["kwarg_types"].iteritems() if name in self.request.GET))
        result = self.run(f, kwargs, kwargs)
        self.response.headers['Content-Type'] = 'text/json'
        self.response.out.write(json.dumps(result, indent=4))

    def post(self):
        GenericRESTRequestHandler.setCurrent(self.request, self.response)
        key = self.request.path, "post"
        if not key in _exposed:
            self.response.set_status(404, "Call not found!")
            return
        f = _exposed[(self.request.path, "post")]
        if self.request.headers.get('Content-Type', "").startswith('application/json-rpc'):
            parameters = json.loads(self.request.body)
        else:
            parameters = json.loads(self.request.POST['data'])
        kwargs = parse_parameters(f, parameters)
        result = self.run(f, parameters, kwargs)
        self.response.headers['Content-Type'] = 'text/json'
        self.response.out.write(json.dumps(result))

    def run(self, f, parameters, kwargs):
        for hook in _precall_hooks:
            hook(f, parameters)
        try:
            result = run(f, kwargs)
        except Exception, e:
            for hook in _postcall_hooks:
                hook(f, False, e)
            raise
        for hook in _postcall_hooks:
            hook(f, True, result)
        return result


def rest_functions(module, authentication=AUTHENTICATED):
    if not authentication in (AUTHENTICATED, NOT_AUTHENTICATED):
        raise ValueError()
    for f in (function for (name, function) in inspect.getmembers(module, lambda x: inspect.isfunction(x))):
        if hasattr(f, 'meta') and "rest" in f.meta and f.meta["rest"]:
            if (authentication == AUTHENTICATED and f.meta["authenticated"]) \
                or (authentication == NOT_AUTHENTICATED and not f.meta["authenticated"]):
                meta_uri = f.meta["uri"]
                meta_method = f.meta["method"]
                for uri in (meta_uri if isinstance(meta_uri, (list, tuple)) else (meta_uri,)):
                    _exposed[(uri, meta_method)] = f
                    yield uri, GenericRESTRequestHandler
