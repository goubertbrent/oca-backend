# -*- coding: utf-8 -*-
# COPYRIGHT (C) 2011-2015 MOBICAGE NV
# ALL RIGHTS RESERVED.
#
# ALTHOUGH YOU MAY BE ABLE TO READ THE CONTENT OF THIS FILE, THIS FILE
# CONTAINS CONFIDENTIAL INFORMATION OF MOBICAGE NV. YOU ARE NOT ALLOWED
# TO MODIFY, REPRODUCE, DISCLOSE, PUBLISH OR DISTRIBUTE ITS CONTENT,
# EMBED IT IN OTHER SOFTWARE, OR CREATE DERIVATIVE WORKS, UNLESS PRIOR
# WRITTEN PERMISSION IS OBTAINED FROM MOBICAGE NV.
#
# THE COPYRIGHT NOTICE ABOVE DOES NOT EVIDENCE ANY ACTUAL OR INTENDED
# PUBLICATION OF SUCH SOURCE CODE.
#
# @@license_version:1.8@@

class MissingClass(object):
    def __reduce__(self):
        # See pickle documentation:
        #
        # If a string is returned, the string should be interpreted as the name of a global variable.
        # It should be the objects local name relative to its module; the pickle module searches the module
        # namespace to determine the objects module. This behaviour is typically useful for singletons.
        return 'MISSING'

MISSING = MissingClass()
del MissingClass

AUTHENTICATED = "authenticated"
NOT_AUTHENTICATED = "non_authenticated"
